---
name: brand-guidelines
description: Applies official brand colors, typography, design tokens, logo assets, and UI component styles to any artifact, website, or document. Use when brand guidelines, visual identity, design systems, CSS tokens, or company styling standards apply.
license: Complete terms in LICENSE.txt
---

# Brand Guidelines & Visual Identity System

## Overview

This skill defines and applies official brand identity, color palettes, typography, UI component styles, and design system tokens.

**Keywords**: branding, corporate identity, visual identity, styling, brand colors, typography, design tokens, UI components, brand guidelines, visual design

---

## Extracted Brand Guidelines & Design Tokens

### 🎨 Color Palette

**Main & Surface Colors:**
- **Primary**: `#141413` / `#111827` - Primary brand elements, main text, and dark headers
- **Light / Background**: `#FAF9F5` / `#FFFFFF` - Page background and light card surfaces
- **Secondary / Surface**: `#4B5563` - Secondary text, subtitles, and borders
- **Mid Gray**: `#B0AEA5` - Muted text and disabled states
- **Light Gray**: `#E8E6DC` - Subtle dividers and background accents

**Accent Colors:**
- **Primary Accent (Orange)**: `#D97757` / `#D97706` - Primary CTAs, highlights, and main buttons
- **Secondary Accent (Blue)**: `#6A9BCC` - Secondary actions, badges, and link highlights
- **Tertiary Accent (Green)**: `#788C5D` - Success indicators and eco/trust badges

---

### 🔤 Typography & Font Stacks

- **Heading Font**: `Poppins`, `Playfair Display` (with `Georgia` / `Arial` fallback)
- **Body Font**: `Lora`, `Inter` (with `Arial` fallback)
- **Code Font**: `Roboto Mono`, `Courier New` (monospace)

#### Font Hierarchy & Scale
- **H1 (Hero Heading)**: `48px` / Bold (`700`) / Line Height `1.2`
- **H2 (Section Header)**: `36px` / SemiBold (`600`) / Line Height `1.25`
- **H3 (Card Title)**: `24px` / Medium (`500`) / Line Height `1.3`
- **Body Text**: `16px` / Regular (`400`) / Line Height `1.5`
- **Caption / Muted**: `14px` / Regular (`400`)

---

## 🖼️ Brand Assets & Media Guidelines

- **Primary Logo**: Logo graphic with transparent background or high contrast SVG/PNG
- **Hero Image / OG Banner**: High quality header image (1200x630 or wide aspect ratio)
- **Favicon**: High resolution favicon (32x32 / 64x64 ico or svg)

---

## 🔘 UI Component Design Tokens

- **Base Spacing Unit**: `8px` (multiples: `8px`, `16px`, `24px`, `32px`, `48px`)
- **Border Radius**: `8px` (Pills: `9999px`)
- **Primary Button**:
  - Background: `var(--color-accent)` (`#D97757` / `#D97706`)
  - Text Color: `#FFFFFF`
  - Border Radius: `8px`
  - Padding: `12px 24px`
  - Hover Effect: Scale `1.02` & brightness boost
- **Secondary Button**:
  - Background: `transparent`
  - Text Color: `var(--color-primary)` (`#141413`)
  - Border: `1px solid var(--color-primary)`
  - Border Radius: `8px`
- **Card Components**:
  - Background: `#FFFFFF` / `var(--color-bg-light)`
  - Shadow: `0 4px 12px rgba(0, 0, 0, 0.08)`
  - Border: `1px solid rgba(0, 0, 0, 0.06)`

---

## 💻 Exported CSS Tokens (`brand-tokens.css`)

```css
:root {
  /* Color Tokens */
  --color-primary: #141413;
  --color-secondary: #4b5563;
  --color-accent: #d97757;
  --color-accent-blue: #6a9bcc;
  --color-accent-green: #788c5d;
  --color-bg: #faf9f5;
  --color-bg-card: #ffffff;
  --color-text: #141413;
  --color-text-muted: #b0aea5;

  /* Typography */
  --font-heading: 'Poppins', 'Playfair Display', Georgia, serif;
  --font-body: 'Lora', 'Inter', Arial, sans-serif;
  --font-code: 'Roboto Mono', monospace;

  /* Spacing & Borders */
  --border-radius: 8px;
  --border-radius-pill: 9999px;
  --space-unit: 8px;
  --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}
```

---

## 🚀 Application & Best Practices

1. **Hierarchy First**: Always maintain high contrast between `--color-bg` and `--color-text`.
2. **Consistent Spacing**: Use increments of the base spacing unit (`8px`, `16px`, `24px`).
3. **Smart Font Fallbacks**: Always provide fallbacks (`sans-serif`, `serif`, `monospace`) in stylesheets.
4. **Interactive States**: Buttons and interactive cards should feature subtle micro-animations (hover transitions: `all 0.2s ease-in-out`).
